<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.main-layout','data' => ['title' => ''.e($title).'']]); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e($title).'']); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form-new-button','data' => ['label' => 'اضافة عضو جديد','action' => 'users.newCreate']]); ?>
<?php $component->withName('form-new-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'اضافة عضو جديد','action' => 'users.newCreate']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <?php if(Session::has('success')): ?>
    <div class="alert alert-info"><?php echo e(Session::get('success')); ?></div>
    <?php endif; ?>
    <div class="container-fluid" >
        <table class="table table-striped" style="width:90%; margin-bottom:0">
            <thead style="color: #21457d">
                <tr >
                    <th scope="col">الاسم</th>
                    <th scope="col">رقم الجوال</th>
                    <th scope="col">حول</th>
                    <th scope="col">الصورة</th>
                  
                    <th scope="col">الدائرة</th>
                    <th scope="col" >
                        تاريخ الانشاء
                    </th>
                    <th scope="col" style="text-align: center">
                        
                    </th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($user->name); ?></th>
                    <td><?php echo e($user->phone_number); ?></td>
                    <td class="report"><?php echo e($user->about); ?></td>
                    <td><img width="60" style="border-radius: 6px"  src="<?php echo e($user->image_path); ?>" alt=""></td>
            
                    <?php if($user->type == 2): ?>    
                    <td id='type' style="width: 25%">
                        <?php if($user->council->parent == null): ?>
                           <?php echo e($user->council->name); ?>

                        <?php else: ?>
                        <?php echo e($user->council->parent->name); ?> 
                        [<?php echo e($user->council->name); ?>]
                        <?php endif; ?>
                    </td>
                    <?php else: ?>
                    <td><?php echo e($user->user_type); ?></td>
                    <?php endif; ?>
                    <td class="report"><?php echo e($user->created_at); ?></td>
                       <td>
                        <a class="btn btn-sm btn-primary" href='<?php echo e(route('users.edit', [$user->id])); ?>'>
                         <div style="width: 60px" class="d-flex justify-content-between align-items-center">                        
                        <i class="far fa-edit" style="margin-right:5px"></i> <span>تعديل</span>
                        </div>
                        </a>
                    </td>
                    <form class="delet-element" action="<?php echo e(route('users.destroy',[$user->id])); ?>" method="POST">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <td>
                            <button type="submit" class="btn btn-sm btn-danger">
                             <div style="width: 55px" class="d-flex justify-content-between align-items-center">                        
                             <i class="far fa-trash-alt" style="margin-right:5px"></i> <span>حذف</span>
                             </div>
                             </button>

                        </td>
                    </form>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
        <?php if($users instanceof \Illuminate\Pagination\AbstractPaginator): ?>

        <?php echo e($users->withQueryString()->links()); ?>

     

        <?php endif; ?>

    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\NOOR AL FAJR\Desktop\projects\host\resources\views/admin/users/index.blade.php ENDPATH**/ ?>