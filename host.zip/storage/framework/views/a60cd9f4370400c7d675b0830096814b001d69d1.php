

<div class="m-2" style=" padding:15px ;dir:rtl">
  <a class="btn" style="background: #1e2f48;color:#fff;padding: 7px;" href="<?php echo e(route("$action", $id ?? '')); ?>"><?php echo e($label); ?></a>
</div><?php /**PATH C:\Users\NOOR AL FAJR\Desktop\projects\host\resources\views/components/form-new-button.blade.php ENDPATH**/ ?>