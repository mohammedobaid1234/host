<?php 

return [
    
    'comments.view.any' => 'View any Comment',
    'comments.view' => 'View Comment',
    'comments.create' => 'Create new Comment',
    'comments.update' => 'Update Comment',
    'comments.delete' => 'Delete Comment',

    'tweets.view.any' => 'View any tweet',
    'tweets.view' => 'View tweet',
    'tweets.create' => 'Create new tweet',
    'tweets.update' => 'Update tweet',
    'tweets.delete' => 'Delete tweet',
    
    'roles.view.any' => 'View any role',
    'roles.view' => 'View role',
    'roles.create' => 'Create new role',
    'roles.update' => 'Update role',
    'roles.delete' => 'Delete role',

];